

###### (Automatically generated documentation)

# Remove orphaned objects from IDF

## Description
This measure removes any remaining orphan objects from the IDF. This measure should be set as an always run measure before simulation can continue in order to avoid simulation crashes / Fatal errors.

## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments



